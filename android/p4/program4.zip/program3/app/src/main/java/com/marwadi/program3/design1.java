package com.marwadi.program3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class design1 extends AppCompatActivity {
    TextView txt1,txt2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_design1);
        txt1.findViewById(R.id.txt1);
        txt2.findViewById(R.id.txt2);
        Intent intent =getIntent();
        txt1.setText(intent.getStringExtra("name"));
        txt2.setText(intent.getStringExtra("content"));
    }
}