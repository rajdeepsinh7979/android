package com.marwadi.program3;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText e_name,e_content;
    Button action1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        action1.findViewById(R.id.action1);
        e_name.findViewById(R.id.m_e_name);
        e_content.findViewById(R.id.m_e_content);

        action1.setOnClickListener(v -> {
            String name=e_name.getText().toString();
            String content=e_content.getText().toString();

            Intent intent=new Intent(MainActivity.this,design1.class);
            intent.putExtra("name",name);
            intent.putExtra("content",content);

        });
    }
}