package com.tc.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {


    Button btn_l,btn_r;
    EditText username,password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            btn_l = findViewById(R.id.btn_login);
            btn_r = findViewById(R.id.btn_ra);
            username = findViewById(R.id.username);
            password = findViewById(R.id.password);

            btn_r.setOnClickListener(view -> {
                SharedPreferences sp = getSharedPreferences("Data",MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("user",username.getText().toString());
                editor.putString("pass",password.getText().toString());
                editor.apply();
                Toast.makeText(this, "user craeted", Toast.LENGTH_SHORT).show();
            });
            btn_l.setOnClickListener(view -> {
                SharedPreferences sp = getSharedPreferences("Data",MODE_PRIVATE);
                if(sp.contains("user")){
                    String user = sp.getString("user","");
                    String pass = sp.getString("pass","");
                    if(user.equals(username.getText().toString())&& pass.equals(password.getText().toString())){
                        Toast.makeText(this, "Welcome", Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(this, "not found", Toast.LENGTH_SHORT).show();
                    }
                }else {
                    Toast.makeText(this, "No record found", Toast.LENGTH_SHORT).show();
                }
            });
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}