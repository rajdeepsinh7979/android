package com.marwadi.project5;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView txtview;
    CheckBox checkbox;
    ToggleButton tgb;

    Switch sw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {

            txtview=findViewById(R.id.txtview);
            checkbox=findViewById(R.id.checkbox);
            tgb=findViewById(R.id.tgb);
            sw=findViewById(R.id.sw);

            checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(checkbox.isChecked())
                    {
                        txtview.setTextSize(30);
                    } else{
                        txtview.setTextSize(20);
                    }
                }
            });

            tgb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(tgb.isChecked())
                    {
                        txtview.setTextSize(30);
                    } else{
                        txtview.setTextSize(20);
                    }
                }
            });
            sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(sw.isChecked())
                    {
                        txtview.setTextSize(30);
                        txtview.setTextColor(Color.parseColor("#FF0000FF"));
                    } else{
                        txtview.setTextSize(20);
                    }
                }
            });

            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}