package com.marwadi.program4;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    RadioGroup rG;
    RadioButton btn1,btn2,btn3;

    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        rG = findViewById(R.id.m_i_radio);
        btn1= findViewById(R.id.btn1);
        btn2= findViewById(R.id.btn2);
        btn3= findViewById(R.id.btn3);
        img=findViewById(R.id.img);

        rG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(btn1.isChecked())
                {
                    img.setImageResource(R.drawable.india);
                } else if (btn2.isChecked()) {
                    img.setImageResource(R.drawable.afghanistan);
                } else if (btn3.isChecked()) {
                    img.setImageResource(R.drawable.australia);
                }
            }
        });
    }
}